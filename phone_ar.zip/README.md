# ns2250225.github.io
AR游戏王项目

# 执行步骤
- 用Android Chrome打开: https://www.ropy.site
- 扫码Marker，等待1-2分钟，由于动画加载时间较长

# Marker
![](marker.png)


# 效果图
![](screenshot.png)
